package salaberry.thiago.p1.pkg122;

public class AnimalDuplicadoException extends Exception {
    private static final String MENSAJE_DEFAULT = "Animal duplicado.";
    
    public AnimalDuplicadoException() {
           this(MENSAJE_DEFAULT);
    }
    
    public AnimalDuplicadoException(String mensajeError) {
        super(mensajeError);
    }
}
