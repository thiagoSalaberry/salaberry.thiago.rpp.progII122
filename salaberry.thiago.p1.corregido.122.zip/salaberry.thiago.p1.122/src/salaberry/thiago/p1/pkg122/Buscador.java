package salaberry.thiago.p1.pkg122;

public interface Buscador {
    void buscarAlimento();
}
