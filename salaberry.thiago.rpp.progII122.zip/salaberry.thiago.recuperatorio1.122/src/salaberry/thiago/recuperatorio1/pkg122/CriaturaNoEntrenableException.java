package salaberry.thiago.recuperatorio1.pkg122;

public class CriaturaNoEntrenableException extends Exception {
    private static final String MENSAJE_DEFAULT = "Esta Criatura no puede entrenar.";
    
    public CriaturaNoEntrenableException() {
           this(MENSAJE_DEFAULT);
    }
    
    public CriaturaNoEntrenableException(String mensajeError) {
        super(mensajeError);
    }
}