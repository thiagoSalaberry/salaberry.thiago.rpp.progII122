package salaberry.thiago.recuperatorio1.pkg122;

import java.util.ArrayList;

public class SalaberryThiagoRecuperatorio1122 {
    public static void main(String[] args) {
        ReinoMedieval reinoMedieval = new ReinoMedieval();
        
        Dragon d1 = new Dragon("Chimuelo", "Reino perdido", NivelMagia.ALTO, 90);
        Dragon d2 = new Dragon("Drakarys", "King's Landing", NivelMagia.MEDIO, 75);
        Elfo e1 = new Elfo("Elfinho", "Brasil", NivelMagia.BAJO, "Elástica");
        Golem g1 = new Golem("La Roca", "Cantera", NivelMagia.ALTO, 15.0);
        
        try {
            reinoMedieval.agregarCriatura(d1);
            reinoMedieval.agregarCriatura(d2);
            reinoMedieval.agregarCriatura(e1);
            reinoMedieval.agregarCriatura(g1);
        } catch(CriaturaDuplicadaException e) {
            System.out.println(e.getMessage());
        }
        
        System.out.println("Todas las criaturas.");
        reinoMedieval.mostrarCriaturas();
        
        System.out.println("Hora de entrenar.");
        try {
            reinoMedieval.entrenarCriaturas();
        } catch(CriaturaNoEntrenableException e) {
            System.out.println(e.getMessage());
        }
        
        System.out.println("Hora de regenerar energías");
        try {
            reinoMedieval.regenerarEnergias();
        } catch(CriaturaNoRegenerableException e) {
            System.out.println(e.getMessage());
        }
        
        ArrayList<Criatura> nivelAlto = reinoMedieval.filtrarPorNivelDeMagia(NivelMagia.ALTO);
        ArrayList<Criatura> nivelMedio = reinoMedieval.filtrarPorNivelDeMagia(NivelMagia.MEDIO);
        ArrayList<Criatura> nivelBajo = reinoMedieval.filtrarPorNivelDeMagia(NivelMagia.BAJO);
        
        System.out.println("Criatura de nivel de magia ALTO");
        for (Criatura c : nivelAlto) {
            System.out.println(c);
        }
        System.out.println("Criatura de nivel de magia MEDIO");
        for (Criatura c : nivelMedio) {
            System.out.println(c);
        }
        System.out.println("Criatura de nivel de magia BAJO");
        for (Criatura c : nivelBajo) {
            System.out.println(c);
        }
        
        System.out.println("Todos los Dragones");
        reinoMedieval.filtrarPorTipoDeCriatura("dragon");
        
        System.out.println("Todos los Elfos");
        reinoMedieval.filtrarPorTipoDeCriatura("elfo");
        
        System.out.println("Todos los Golems");
        reinoMedieval.filtrarPorTipoDeCriatura("Golem");
    }
    
}
