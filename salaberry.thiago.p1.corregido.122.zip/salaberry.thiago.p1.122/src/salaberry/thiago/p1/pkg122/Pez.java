package salaberry.thiago.p1.pkg122;

public class Pez extends Animal implements Nadador {
    private static final double LONGITUD_MAX = 100.0;
    private double longitud;

    public Pez(double longitud, String nombre, String habitat, TipoAgua tipoAgua) {
        super(nombre, habitat, tipoAgua);
        validarLongitud(longitud);
        this.longitud = longitud;
    }

    public double getLongitud() {
        return longitud;
    }
    
    @Override
    public void nadar() {
        StringBuilder sb = new StringBuilder();
        sb.append("Soy el Pez ");
        sb.append(getNombre());
        sb.append(" y estoy nadando.");
        
        System.out.println(sb.toString());
    }
    
    @Override
    public String toString() {
        return String.format("""
        %s
        Pez
        \tLongitud (cm): %.2f
        """, super.toString(), longitud);
    }
    
    private void validarLongitud(double longitud) {
        if(longitud < 0 || longitud > LONGITUD_MAX) throw new IllegalArgumentException("El parámetro 'longitud' debe ser mayor a 0 y menor o igual que " + LONGITUD_MAX);
    }
}
