package salaberry.thiago.p1.pkg122;

public class Crustaceo extends Animal implements Buscador {
    private int cantPatas;

    public Crustaceo(int cantPatas, String nombre, String habitat, TipoAgua tipoAgua) {
        super(nombre, habitat, tipoAgua);
        validarCantPatas(cantPatas);
        this.cantPatas = cantPatas;
    }

    public int getCantPatas() {
        return cantPatas;
    }
    
    @Override
    public void buscarAlimento() {
        StringBuilder sb = new StringBuilder();
        sb.append("Soy el Crustaceo ");
        sb.append(getNombre());
        sb.append(" y estoy buscando comida.");
        
        System.out.println(sb.toString());
    }
    
    @Override
    public String toString() {
        return String.format("""
        %s
        Crustaceo
        \tCantidad de Patas: %d
        """, super.toString(), cantPatas);
    }
    
    private void validarCantPatas(int cantPatas) {
        if(cantPatas <= 0) throw new IllegalArgumentException("El parámetro 'cantPatas' debe ser mayor a 0.");
    }
}
