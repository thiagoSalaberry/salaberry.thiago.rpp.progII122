package salaberry.thiago.p1.pkg122;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class Acuario {
    private List<Animal> animales;
    
    public Acuario() {
        animales = new ArrayList<>();
    }
    
    public void agregarAnimal(Animal animal) throws AnimalDuplicadoException {
        validarDuplicado(animal);
        animales.add(animal);
    }
    
    public Animal buscarAnimal(Animal animal) {
        Iterator<Animal> it = animales.iterator();
        Animal aBuscar = null;
        
        while(it.hasNext() && aBuscar == null) {
            Animal actual = it.next();
            if(actual.equals(animal)) {
                aBuscar = actual;
            }
        }
        
        return aBuscar;
    }
    
    public void mostrarAnimales() {
        for (Animal a : animales) {
            System.out.println(a);
        }
    }
    
    public void nadar() {
        for (Animal a : animales) {
            if (a instanceof Nadador n) {
                n.nadar();
            }
        }
    }
    
    public void buscarAlimento() {
        for (Animal a : animales) {
            if(a instanceof Buscador b) {
                b.buscarAlimento();
            }
        }
    }
    
    public ArrayList<Animal> filtrarPorTipoAgua(TipoAgua tipoAgua) {
        ArrayList<Animal> resultado = new ArrayList<>();
        for (Animal a : animales) {
            if(a.esDeTipo(tipoAgua)) {
                resultado.add(a);
            }
        }
        
        return resultado;
    }
    
    public void mostrarAnimalesPorTipo(String tipoAnimal) {
        for (Animal a : animales) {
            if(tipoAnimal.equalsIgnoreCase("pez") && a instanceof Pez ||
               tipoAnimal.equalsIgnoreCase("mamiferomarino") && a instanceof MamiferoMarino ||
               tipoAnimal.equalsIgnoreCase("crustaceo") && a instanceof Crustaceo) {
                System.out.println(a);
            }
        }
    }
    
    private void validarDuplicado(Animal animal) throws AnimalDuplicadoException {
        if(buscarAnimal(animal) != null) {
            StringBuilder sb = new StringBuilder();
            sb.append("El animal con nombre '");
            sb.append(animal.getNombre());
            sb.append("' ya existe para el habitat '");
            sb.append(animal.getHabitat());
            sb.append("'");
            throw new AnimalDuplicadoException(sb.toString());
        }
    }
}
