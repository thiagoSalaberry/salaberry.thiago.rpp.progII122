package salaberry.thiago.recuperatorio1.pkg122;

public class Dragon extends Criatura implements Entrenable {
    private int potenciaFuego;

    public Dragon(String nombre, String region, NivelMagia nivelMagia, int potenciaFuego) {
        super(nombre, region, nivelMagia);
        validarPotenciaFuego(potenciaFuego);
        this.potenciaFuego = potenciaFuego;
    }

    public int getPotenciaFuego() {
        return potenciaFuego;
    }
    
    @Override
    public void entrenar() {
        StringBuilder sb = new StringBuilder();
        sb.append("Soy el Dragon ");
        sb.append(getNombre());
        sb.append(" y estoy entrenando.");
        
        System.out.println(sb.toString());
    }
    
    @Override
    public String toString() {
        return String.format("""
        %s
        Dragon{potenciaFuego=%d}""", super.toString(), potenciaFuego);
    }
    
    private void validarPotenciaFuego(int potenciaFuego) {
        if(potenciaFuego <= 0) throw new IllegalArgumentException("El parámetro 'potenciaFuego' debe ser mayor a 0.");
    }

}
