package salaberry.thiago.recuperatorio1.pkg122;

public interface Entrenable {
    void entrenar();
}
