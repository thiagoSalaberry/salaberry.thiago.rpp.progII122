package salaberry.thiago.recuperatorio1.pkg122;

public class CriaturaNoRegenerableException extends Exception {
    private static final String MENSAJE_DEFAULT = "Esta Criatura no regenera energía.";
    
    public CriaturaNoRegenerableException() {
           this(MENSAJE_DEFAULT);
    }
    
    public CriaturaNoRegenerableException(String mensajeError) {
        super(mensajeError);
    }
}
