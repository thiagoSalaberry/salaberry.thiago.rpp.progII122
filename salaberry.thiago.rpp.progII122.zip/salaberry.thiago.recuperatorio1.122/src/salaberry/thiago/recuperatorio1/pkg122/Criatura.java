package salaberry.thiago.recuperatorio1.pkg122;

import java.util.Objects;

public abstract class Criatura {
    private String nombre;
    private String region;
    private NivelMagia nivelMagia;

    public Criatura(String nombre, String region, NivelMagia nivelMagia) {
        validarInitParams(nombre, region, nivelMagia);
        this.nombre = nombre;
        this.region = region;
        this.nivelMagia = nivelMagia;
    }

    public String getNombre() {
        return nombre;
    }

    public String getRegion() {
        return region;
    }

    public NivelMagia getNivelMagia() {
        return nivelMagia;
    }
    
    public boolean esDeNivelMagia(NivelMagia nivelMagia) {
        return this.nivelMagia == nivelMagia;
    }

    @Override
    public String toString() {
        return "Criatura{" + "nombre=" + nombre + ", region=" + region + ", nivelMagia=" + nivelMagia + '}';
    }

    @Override
    public boolean equals(Object obj) {
        if(this == obj) return true;
        if(obj == null || !(obj instanceof Criatura criatura)) return false;
        
        return criatura.nombre.equals(nombre) && criatura.region.equals(region);
    }
    
    @Override
    public int hashCode() {
        return Objects.hash(nombre, region);
    }
    
    private void validarNull(Object o, String mensajeError) {
        Objects.requireNonNull(o, mensajeError);
    }
    
    private void validarInitParams(String nombre, String region, NivelMagia nivelMagia) {
        validarNull(nombre, "Nombre nulo.");
        validarNull(region, "Region nula.");
        validarNull(nivelMagia, "NivelMagia nulo.");
    }
}
