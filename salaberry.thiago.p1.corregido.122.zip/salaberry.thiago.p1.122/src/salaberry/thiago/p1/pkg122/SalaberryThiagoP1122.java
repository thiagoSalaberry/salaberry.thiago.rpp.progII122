package salaberry.thiago.p1.pkg122;

import java.util.ArrayList;

public class SalaberryThiagoP1122 {
    public static void main(String[] args) {
        Acuario acuario = new Acuario();
        
        Pez pez1 = new Pez(20, "El payaso Nemo", "Mar", TipoAgua.SALADA);
        Pez pez2 = new Pez(60.0, "Salmón", "Río", TipoAgua.DULCE);
        MamiferoMarino mm1 = new MamiferoMarino(30, "El delfín Roberto", "Mar", TipoAgua.SALADA);
        Crustaceo c1 = new Crustaceo(6, "Don Cangrejo", "Fondo de Bikini", TipoAgua.SALADA);
        
        try {
            acuario.agregarAnimal(pez1);
            acuario.agregarAnimal(pez2);
            acuario.agregarAnimal(mm1);
            acuario.agregarAnimal(c1);
        } catch(AnimalDuplicadoException e) {
            System.out.println(e.getMessage());
        }
        
        System.out.println("Todos los animales");
        acuario.mostrarAnimales();
        
        System.out.println("Hora de nadar");
        acuario.nadar();
        
        System.out.println("Hora de comer");
        acuario.buscarAlimento();
        
        ArrayList<Animal> aguaDulce = acuario.filtrarPorTipoAgua(TipoAgua.DULCE);
        ArrayList<Animal> aguaSalada = acuario.filtrarPorTipoAgua(TipoAgua.SALADA);
        
        System.out.println("Animales de Agua Dulce");
        for (Animal a : aguaDulce) {
            System.out.println(a);
        }
        
        System.out.println("Animales de Agua Salada");
        for (Animal a : aguaSalada) {
            System.out.println(a);
        }
        
        System.out.println("Peces");
        acuario.mostrarAnimalesPorTipo("pez");
        
        System.out.println("MamiferosMarinos");
        acuario.mostrarAnimalesPorTipo("mamiferoMarino");
        
        System.out.println("Crustaceos");
        acuario.mostrarAnimalesPorTipo("crustaceo");
    }
    
}
