package salaberry.thiago.recuperatorio1.pkg122;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;

public class ReinoMedieval {
    private List<Criatura> criaturas = new ArrayList();
    
    public void agregarCriatura(Criatura criatura) throws CriaturaDuplicadaException {
        validarDuplicado(criatura);
        criaturas.add(Objects.requireNonNull(criatura, "Criatura nula"));
    }
    
    public Criatura buscarCriatura(Criatura criatura) {
        Iterator<Criatura> it = criaturas.iterator();
        Criatura aBuscar = null;
        
        while(it.hasNext() && aBuscar == null) {
            Criatura actual = it.next();
            if(actual.equals(criatura)) {
                aBuscar = criatura;
            }
        }
        
        return aBuscar;
    }
    
    public void mostrarCriaturas() {
        for (Criatura c : criaturas) {
            System.out.println(c);
        }
    }
    
    public void entrenarCriaturas() throws CriaturaNoEntrenableException {
        for (Criatura c : criaturas) {
            if(c instanceof Entrenable e) {            
                e.entrenar();
            } else {
                System.out.println("La Criatura " + c.getNombre() + " no puede entrenar.");
            }
        }
        /*
        Si yo aplico el código comentado, al llamar a esta función en el main, cuando se encuentre con la primera Criatura que no pueda entrenar, va a salir 
        por el catch y las que quedaban por ejecutar entrenar() no van a poder
        for (Criatura c : criaturas) {
            if(!(c instanceof Entrenable e)) throw new CriaturaNoEntrenableException();
            e.entrenar();
        }
        */
    }
    
    public void regenerarEnergias() throws CriaturaNoRegenerableException {
        for (Criatura c : criaturas) {
            if(c instanceof Regenerable r) {
                r.regenerarEnergia();
            } else {
                System.out.println("La Criatura " + c.getNombre() + " no puede regenerar energía.");
            }
        }
        /*
        Si yo aplico el código comentado, al llamar a esta función en el main, cuando se encuentre con la primera Criatura que no pueda regenerar energía,
        va a salir por el catch y las que quedaban por ejecutar regenerarEnergia() no van a poder
        for (Criatura c : criaturas) {
            if(!(c instanceof Regenerable r)) throw new CriaturaNoRegenerableException("La Criatura " + c.getNombre() + " no puede regenerar energía.");
            r.regenerarEnergia();
        }
        */
    }
    
    public ArrayList<Criatura> filtrarPorNivelDeMagia(NivelMagia nivelMagia) {
        ArrayList<Criatura> resultado = new ArrayList<>();
        for (Criatura c : criaturas) {
            if(c.esDeNivelMagia(nivelMagia)) {
                resultado.add(c);
            }
        }
        
        return resultado;
    }
    
    public void filtrarPorTipoDeCriatura(String tipoCriatura) {
        for (Criatura c : criaturas) {
            if(tipoCriatura.equalsIgnoreCase("dragon") && c instanceof Dragon ||
               tipoCriatura.equalsIgnoreCase("elfo") && c instanceof Elfo ||
               tipoCriatura.equalsIgnoreCase("golem") && c instanceof Golem) {
                System.out.println(c);
            }
        }
    }
    
    private void validarDuplicado(Criatura criatura) throws CriaturaDuplicadaException {
        if(buscarCriatura(criatura) != null) {
            StringBuilder sb = new StringBuilder();
            sb.append("La criatura con nombre '");
            sb.append(criatura.getNombre());
            sb.append("' ya existe en la región '");
            sb.append(criatura.getRegion());
            sb.append("'");
            throw new CriaturaDuplicadaException(sb.toString());
        }
    }
}
