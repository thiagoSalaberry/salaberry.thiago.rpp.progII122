package salaberry.thiago.recuperatorio1.pkg122;

public class Golem extends Criatura implements Regenerable {
    private static final double MIN_PESO = 1.0;
    private static final double MAX_PESO = 20.0;
    private double peso;

    public Golem(String nombre, String region, NivelMagia nivelMagia, double peso) {
        super(nombre, region, nivelMagia);
        validarPeso(peso);
        this.peso = peso;
    }

    public double getPeso() {
        return peso;
    }
    
    @Override
    public void regenerarEnergia() {
        StringBuilder sb = new StringBuilder();
        sb.append("Soy el Golem ");
        sb.append(getNombre());
        sb.append(" y estoy regenerando mi energía.");
        
        System.out.println(sb.toString());
    }
    
    @Override
    public String toString() {
        return String.format("""
        %s
        Golem{peso=%.2f}""", super.toString(), peso);
    }
    
    private void validarPeso(double peso) {
        if(peso < MIN_PESO || peso > MAX_PESO) throw new IllegalArgumentException("El parámetro 'peso' debe estar entre " + MIN_PESO + " y " + MAX_PESO);
    }
}
