package salaberry.thiago.recuperatorio1.pkg122;

public class CriaturaDuplicadaException extends Exception {
    private static final String MENSAJE_DEFAULT = "Criatura duplicada.";
    
    public CriaturaDuplicadaException() {
           this(MENSAJE_DEFAULT);
    }
    
    public CriaturaDuplicadaException(String mensajeError) {
        super(mensajeError);
    }
}
