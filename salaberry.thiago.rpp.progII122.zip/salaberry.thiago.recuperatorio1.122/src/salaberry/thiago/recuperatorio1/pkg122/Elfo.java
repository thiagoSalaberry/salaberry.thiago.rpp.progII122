package salaberry.thiago.recuperatorio1.pkg122;

import java.util.Objects;

public class Elfo extends Criatura implements Entrenable, Regenerable {
    private String habilidadEspecial;

    public Elfo(String nombre, String region, NivelMagia nivelMagia, String habilidadEspecial) {
        super(nombre, region, nivelMagia);
        validarHabilidadEspecial(habilidadEspecial);
        this.habilidadEspecial = habilidadEspecial;
    }

    public String getHabilidadEspecial() {
        return habilidadEspecial;
    }
    
    @Override
    public void entrenar() {
        StringBuilder sb = new StringBuilder();
        sb.append("Soy el Elfo ");
        sb.append(getNombre());
        sb.append(" y estoy entrenando mi habilidad especial.");
        
        System.out.println(sb.toString());
    }
    
    @Override
    public void regenerarEnergia() {
        StringBuilder sb = new StringBuilder();
        sb.append("Soy el Elfo ");
        sb.append(getNombre());
        sb.append(" y estoy regenerando mi energía.");
        
        System.out.println(sb.toString());
    }
    
    @Override
    public String toString() {
        return String.format("""
        %s
        Elfo{habilidadEspecial=%s}""", super.toString(), habilidadEspecial);
    }
    
    private void validarHabilidadEspecial(String habilidadEspecial) {
        Objects.requireNonNull(habilidadEspecial, "Parámetro 'habilidadEspecial' nulo.");
    }
}
