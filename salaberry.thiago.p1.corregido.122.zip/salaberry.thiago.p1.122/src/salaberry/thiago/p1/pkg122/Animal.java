package salaberry.thiago.p1.pkg122;

import java.util.Objects;

public abstract class Animal {
    private String nombre;
    private String habitat;
    private TipoAgua tipoAgua;

    public Animal(String nombre, String habitat, TipoAgua tipoAgua) {
        validarParametrosIni(nombre, habitat, tipoAgua);
        this.nombre = nombre;
        this.habitat = habitat;
        this.tipoAgua = tipoAgua;
    }

    public String getNombre() {
        return nombre;
    }

    public String getHabitat() {
        return habitat;
    }

    public TipoAgua getTipoAgua() {
        return tipoAgua;
    }

    public boolean esDeTipo(TipoAgua tipoAgua) {
        return this.tipoAgua.equals(tipoAgua);
    }
    
    @Override
    public String toString() {
        return String.format("""
        Animal
        \tNombre: %s
        \tHabitat: %s
        \tTipo de Agua: %s         
        """, nombre, habitat, tipoAgua);
    }
    
    @Override
    public boolean equals(Object obj) {
        if(this == obj) return true;
        if(obj == null || !(obj instanceof Animal animal)) return false;
        
        return animal.getNombre().equals(getNombre()) && animal.getHabitat().equals(getHabitat());
    }
    
    @Override
    public int hashCode() {
        return Objects.hash(getNombre(), getHabitat());
    }
    
    private void validarNull(Object obj, String mensajeError) {
        if(obj == null) throw new IllegalArgumentException(mensajeError);
    }
    
    private void validarParametrosIni(String nombre, String habitat, TipoAgua tipoAgua) {
        validarNull(nombre, "El parámetro 'nombre' es nulo.");
        validarNull(habitat, "El parámetro 'habitat' es nulo.");
        validarNull(tipoAgua, "El parámetro 'tipoAgua' es nulo.");
    }
}
