package salaberry.thiago.p1.pkg122;

public enum TipoAgua {
    DULCE,
    SALADA
}
