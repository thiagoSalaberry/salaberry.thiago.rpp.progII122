package salaberry.thiago.p1.pkg122;

public class MamiferoMarino extends Animal implements Nadador, Buscador{
    private int frecuenciaRespiracion;

    public MamiferoMarino(int frecuenciaRespiracion, String nombre, String habitat, TipoAgua tipoAgua) {
        super(nombre, habitat, tipoAgua);
        validarFrecuenciaRespiracion(frecuenciaRespiracion);
        this.frecuenciaRespiracion = frecuenciaRespiracion;
    }

    public int getFrecuenciaRespiracion() {
        return frecuenciaRespiracion;
    }
    
    @Override
    public void nadar() {
        StringBuilder sb = new StringBuilder();
        sb.append("Soy el Mamifero Marino ");
        sb.append(getNombre());
        sb.append(" y estoy nadando.");
        
        System.out.println(sb.toString());
    }
    
    @Override
    public void buscarAlimento() {
        StringBuilder sb = new StringBuilder();
        sb.append("Soy el Mamifero Marino ");
        sb.append(getNombre());
        sb.append(" y estoy buscando comida.");
        
        System.out.println(sb.toString());
    }
    
    @Override
    public String toString() {
        return String.format("""
        %s
        MamiferoMarino
        \tFrecuencia de Respiracion (s): %d
        """, super.toString(), frecuenciaRespiracion);
    }
    
    private void validarFrecuenciaRespiracion(int frecuenciaRespiracion) {
        if(frecuenciaRespiracion <= 0) throw new IllegalArgumentException("El parámetro 'frecuenciaRespiracion' debe ser mayor a 0.");
    }
}
